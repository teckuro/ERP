# Roadmap operativo ERP Remuneraciones Chile

## 1. Proposito

Este documento ordena el avance funcional del ERP de remuneraciones chileno.

Su objetivo es evitar avanzar por intuicion, por UI o por presion de implementar rapido sin cerrar dependencias criticas.

Cursor/Codex no decide el camino del proyecto. Cursor/Codex solo puede ejecutar fases cuando este roadmap define alcance, limites, dependencias y criterios de cierre.

## 2. Principio rector

Prioridad actual:

1. Funcionalidad correcta.
2. Reglas de negocio consistentes.
3. Datos confiables.
4. Seguridad y permisos.
5. Trazabilidad.
6. UI minima correcta.
7. Pulido visual final posterior.

No se debe hacer perfeccion visual en cada fase.

## 3. Estado macro

| Area                  | Estado           | Observacion                                                                                     |
| --------------------- | ---------------- | ----------------------------------------------------------------------------------------------- |
| Orquestador / roadmap | Cerrada          | ORDEN-01 integrada; SEG-01 queda como siguiente fase oficial                                    |
| Empleados             | Cerrado          | Alta, borrador, continuar alta, aptitud para remuneraciones                                     |
| Parametros            | Cerrado          | Periodo, vigencias, catalogos, carga mensual                                                    |
| Seguridad / permisos  | En definicion    | SEG-01 documenta roles, permisos, JWT/RLS base y acciones bloqueadas antes de endurecer modulos |
| Conceptos             | Parcial          | CONC-02 queda despues de SEG-01; faltan reglas finales para motor                               |
| Haberes recurrentes   | Cerrado base     | Asignaciones recurrentes por periodo                                                            |
| Movimientos variables | Parcial avanzado | Existe base manual, faltan mejoras futuras                                                      |
| Proceso mensual       | Parcial          | Prevalidaciones 9.5A y 9.5B cerradas, sin motor                                                 |
| Motor de calculo      | Pendiente        | No implementar antes de cerrar conceptos y contrato de motor                                    |
| Liquidaciones         | Pendiente real   | No usar UI demo como productiva                                                                 |
| Previred              | Pendiente        | Depende de liquidaciones reales                                                                 |
| LRE                   | Pendiente        | Depende de conceptos mapeados y liquidaciones                                                   |
| Reportes              | Pendiente        | Depende de cierre/liquidaciones                                                                 |
| Pulido visual final   | Pendiente        | Agrupar en fase posterior                                                                       |

## 4. Orden recomendado

1. ORDEN-01 - Integracion final del roadmap (**Cerrada**)
2. SEG-01 - Roles, permisos, JWT/RLS base (**En definicion**)
3. CONC-02 - Conceptos gobernados para motor
4. MOTOR-00 - Contrato del motor de calculo
5. MOTOR-01 - Motor de calculo v1 acotado
6. LIQ-01 - Liquidaciones snapshot
7. CIERRE-01 - Cierre mensual
8. PREVIRED-01 - Base exportacion Previred
9. LRE-01 - Libro de Remuneraciones Electronico
10. REPORTES-01 - Reportes y auditoria
11. UX-FINAL-01 - Pulido visual integral

Regla de orden:

- CONC-02 no debe ejecutarse antes de SEG-01.
- MOTOR-00 debe cerrarse antes de cualquier implementacion de motor.
- MOTOR-01, liquidaciones, cierre, Previred y LRE quedan bloqueados hasta cumplir sus dependencias.

## 5. Regla de avance

Una fase solo puede comenzar si:

- Tiene objetivo claro.
- Tiene alcance claro.
- Tiene que no tocar.
- Tiene dependencias cerradas.
- Tiene criterios de aceptacion.
- Tiene validacion manual o automatica.
- Tiene documentacion a actualizar.

## 6. Fase actual: SEG-01

SEG-01 es la fase actual de ordenamiento documental de seguridad y permisos.

Objetivo:

- Definir roles base.
- Definir acciones por modulo.
- Separar permisos UI, service y BD/JWT/RLS.
- Definir acciones criticas.
- Definir acciones bloqueadas por fases futuras.
- Definir que queda `A_DEFINIR` para subfase posterior.

Documento principal:

- [`matriz-roles-permisos.md`](./matriz-roles-permisos.md)

Estado esperado al cierre documental:

`Cerrada base`

Despues de SEG-01, la siguiente fase oficial es:

`CONC-02 - Conceptos gobernados para motor`

Regla:

- No avanzar a `CONC-02` sin matriz de roles/permisos revisada.
- No avanzar a `MOTOR-00` sin `CONC-02`.
- No implementar motor, liquidaciones, cierre, Previred ni LRE desde SEG-01.
