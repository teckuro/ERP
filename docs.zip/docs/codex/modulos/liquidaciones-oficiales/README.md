# Modulo Liquidaciones oficiales

## Estado

| Campo | Valor |
|---|---|
| Estado actual | Implementado v1 interno |
| Fase de diseno | `LIQ-DESIGN-01` |
| Fase de implementacion | `LIQ-OFICIAL-01` |
| Dependencia | Nomina cerrada operativamente |
| Implementado | Si |

Este modulo implementa liquidaciones oficiales internas v1 desde una nomina cerrada operativamente. La implementacion materializa el snapshot cerrado en tablas propias y permite revisar resumen, trabajadores y detalle de conceptos en UI.

## Objetivo del modulo

Generar y consultar liquidaciones oficiales por trabajador desde una nomina cerrada operativamente.

Principio:

```txt
La liquidacion oficial no recalcula.
La liquidacion oficial presenta y persiste el resultado del snapshot cerrado.
```

## Flujo objetivo

```txt
Preparar nomina
-> Resultado preliminar guardado
-> Aprobacion operativa
-> Cierre operativo
-> Liquidaciones oficiales
```

## Que cubre v1

```txt
estado de liquidaciones del periodo
generacion de liquidaciones desde snapshot cerrado
cabecera de liquidacion por periodo
liquidacion por trabajador
detalle de conceptos por trabajador
resumen de haberes, descuentos y liquido a pagar
trazabilidad al snapshot cerrado
```

## Implementacion LIQ-OFICIAL-01

- SQL versionado: `bd/base/v11/partes/22_liquidaciones_oficiales.sql`.
- RPC versionada: `bd/base/v11/partes/23_liquidaciones_oficiales_rpc.sql`.
- RPC: `generar_liquidaciones_oficiales`, `SECURITY INVOKER`, solo `authenticated`, sin `anon`.
- Feature Angular: `src/app/features/liquidaciones-oficiales/`.
- Ruta: `/remuneraciones/liquidaciones-oficiales`.
- Entrada desde `Preparar nomina` cuando la nomina esta cerrada operativamente.
- E2E real: `tests/liquidaciones-oficiales.e2e.spec.ts` con skip seguro si faltan flags.

## Validacion LIQ-DB-APPLY-01

- Periodo real controlado: `2026-04`.
- Snapshot origen: `id_calculo_periodo=1`, aprobado y cerrado operativamente.
- Liquidacion generada: `id_liquidacion_periodo=1`.
- Resultado BD: 1 trabajador, 8 conceptos, duplicados activos 0.
- Totales validados cabecera = detalle: haberes `750001.88`, descuentos `588301.48`, liquido `161700.40`.
- E2E real: nomina mensual OK y liquidaciones oficiales OK.

## Fuera de alcance v1

```txt
PDF
firma
recepcion
envio por correo
portal trabajador
Previred
LRE
banco
contabilidad
reapertura
anulacion
rectificacion
reliquidacion
```

## Documentos

| Documento | Rol |
|---|---|
| `contrato-general.md` | Contrato funcional, datos y UX del modulo |
| `../../fases/liquidaciones/LIQ-DESIGN-01.md` | Diseno funcional y tecnico de la fase |
| `../nomina-mensual/contrato-general.md` | Fuente del cierre operativo |
| `../nomina-mensual/motor-calculo-persistencia-03B.md` | Persistencia y snapshot origen |

## Siguiente fase recomendada

```txt
UX-COMERCIAL-01 - Redisenar experiencia usable, dinamica y comercial
```
