# Liquidaciones oficiales - contrato general

## Estado del contrato

| Campo | Valor |
|---|---|
| Version | v1 implementada |
| Estado | Implementado interno |
| Fase asociada | `LIQ-OFICIAL-01` |
| Implementacion | SQL/RPC/Angular/tests/docs |
| Siguiente fase | `UX-COMERCIAL-01` |

## Definicion

La liquidacion oficial es el comprobante consolidado por trabajador, generado desde un snapshot de nomina cerrado operativamente, que presenta haberes, descuentos, bases, referencias y liquido a pagar del periodo, con trazabilidad al calculo que la origino.

## Regla principal

```txt
Liquidaciones oficiales no recalcula.
Liquidaciones oficiales materializa el snapshot cerrado.
```

## Precondiciones

```txt
periodo valido
snapshot activo
snapshot aprobado operativamente
snapshot cerrado operativamente
snapshot no reemplazado
sin liquidaciones previas generadas para el snapshot
trabajadores calculados existentes
usuario authenticated
```

## Estados visibles

```txt
No disponible
Lista para generar
Generando
Generadas
Generadas con advertencias
Error de generacion
```

## Bloqueos

```txt
no hay cierre operativo
snapshot no aprobado
snapshot reemplazado
liquidaciones ya generadas
no hay trabajadores calculados
usuario sin sesion
error tecnico de BD/RPC
```

## Advertencias no bloqueantes

```txt
concepto sin codigo LRE
correo trabajador faltante
datos bancarios incompletos
firma/recepcion no configurada
observaciones informativas
```

No bloquear por requerimientos de fases futuras.

## Persistencia implementada

### `nomina_liquidacion_periodo`

Cabecera por periodo/snapshot.

### `nomina_liquidacion_trabajador`

Comprobante por trabajador.

### `nomina_liquidacion_concepto`

Detalle por concepto.

## RPC implementada

```txt
generar_liquidaciones_oficiales
```

Debe ser:

```txt
atomica
security invoker
solo authenticated
sin anon
sin service_role desde frontend
```

La RPC valida snapshot activo, periodo coincidente, aprobacion operativa, cierre operativo, `reemplazado_por is null`, existencia de trabajadores y ausencia de liquidacion activa previa para el mismo `id_calculo_periodo`. La generacion inserta cabecera, trabajadores y conceptos, actualiza totales desde lo insertado y retorna la cabecera.

## UI esperada

Pantalla o container propio, con entrada desde Preparar nomina.

Estructura:

```txt
Header operativo
Estado del periodo
Resumen de liquidaciones
Siguiente accion
Bloqueos/advertencias
Listado de trabajadores
Detalle trabajador
Trazabilidad tecnica secundaria
```

Boton principal:

```txt
Generar liquidaciones oficiales
```

Helper obligatorio:

```txt
Se generaran comprobantes por trabajador desde la nomina cerrada. No se recalcularan montos ni se generaran PDF, Previred, LRE, banco o contabilidad.
```

Nota de deuda UX: `LIQ-OFICIAL-01` usa `window.confirm` temporal para confirmar generacion. Debe reemplazarse por modal/MessageBox estandar en `UX-COMERCIAL-01`.

## Fuera de alcance del contrato v1

```txt
PDF
firma
recepcion
envio
portal trabajador
Previred
LRE
banco
contabilidad
reapertura
anulacion
rectificacion
reliquidacion
```

## Criterios LIQ-OFICIAL-01

```txt
[x] Cierre operativo validado en BD real/controlada.
[x] Contrato de tablas revisado.
[x] RPC definida e implementada.
[x] UI no promete PDF/firma/Previred/LRE/banco.
[x] Feature Angular creada fuera de pages.
[x] Tests unitarios y E2E seguro definidos.
[x] Documentacion actualizada.
```
