# Plan de pruebas por módulo

Este documento consolida los tipos de pruebas existentes y propone un plan de pruebas para cada módulo del ERP de remuneraciones.  Su propósito es asegurar que las reglas de negocio, la UI y las integraciones se comporten según el contrato.  Las pruebas deben actualizarse cuando cambien los contratos funcionales o la implementación.

## Enfoques generales

1. **Pruebas unitarias** - validan la lógica de reglas puras, servicios y helpers en aislamiento.  Se ejecutan con Vitest/Angular (`ng test`) y se enfocan en casos positivos y negativos.  Son obligatorias para los helpers de estados, validadores de vigencia, reglas de asignabilidad y cualquier cálculo en el cliente.
2. **Pruebas de integración** - verifican que contenedores y páginas integren correctamente servicios y reglas.  Se implementan con Vitest o con utilidades de Angular; deben usar mocks de repositorios y mirar cambios en el DOM.
3. **Pruebas E2E / UI** - simulan interacción de usuario usando Playwright.  Capturan snapshots, validan flujos clave, mensajes de estado, navegación y deshabilitado de botones según permisos.  Pueden integrarse con assets para comparaciones visuales.
4. **Assets y snapshots** - se usan para detectar regresiones visuales en componentes.  Las capturas se guardan bajo `docs/codex/assets/<modulo>/` y no deben incluir datos sensibles.  Se renuevan cuando se aprueba un cambio visual.
5. **Brechas** - se documentan los huecos conocidos en la cobertura de pruebas; deben cerrarse en futuras fases.

## Tabla resumen

| Módulo | Unitarios recomendados | Integración / E2E | Activos en repo | Brechas identificadas |
|-------|-----------------------|------------------|-----------------|----------------------|
| **Empleados** | Validar completitud/aptitud (`empleado-completitud.rules.ts`), reglas de borrador y wizard, cálculo de acción principal, helpers de validación de ficha. | E2E de alta básica (`empleados-basic-create.spec.ts`), borrador avanzado, wizard (scroll y pasos), dashboard con creación de ficha.  Tests de listado deberían validar acciones y estados. | Véase `tests-empleados.md`: helpers unitarios, contenedores de ficha (`ficha-empleado-container.spec.ts`), borrador/hidratación y seleccionadores del orquestador. | No hay tests de ficha `/empleados/:id` con datos reales (depende de Supabase).  Falta E2E para editar/validar ficha y visualizar la acción de “Validar para remuneraciones”. |
| **Parámetros** | Reglas de período/vigencia/catalogo (`applyVigenciaSolapaPeriodo`), filtros de UI, estados de `periodo_remuneracion`, helpers de prevalidación de grupos mínimos. | Playwright para tabs y subtabs (`parametros-tabs.screenshots.spec.ts`), snapshot de dashboard (`dashboard.spec.ts`).  Deben agregarse flujos de edición y guardado al completar catálogos cuando existan RLS y datos reales. | `tests-parametros.md` documenta solo capturas y suite unitaria genérica; los scripts Python se prueban por separado. | No hay cobertura E2E para edición/guardado de cada catálogo; depende de roles/JWT y datos reales.  Se recomienda checklist manual hasta que se definan flujos de CRUD en UI. |
| **Conceptos de remuneración** | Regla de asignabilidad (`concepto-asignabilidad.rules.ts`), rule de acciones (`concepto-acciones.rules.ts`), validador de vigencia. | E2E de listado base (`conceptos-remuneracion-listado.spec.ts`), modal “Revisar” y evaluación de acciones permitidas.  Deben agregarse pruebas para Fase 9.3A (asignaciones en Haberes) y 9.4A (movimientos variables). | No se encontró una suite de tests consolidada en la carpeta actual; se deduce de las reglas. | Faltan tests de CRUD completo, RLS/JWT y reglas de cálculo.  Tampoco se prueba la coherencia entre vigencia de conceptos y asignaciones históricas. |
| **Haberes y descuentos** | Validar vigencia de asignaciones (`haber-descuento-vigencia.rules.ts`), solapamientos y fechas incoherentes, reglas de cierre/desactivación. | E2E para creación, edición y cierre de asignaciones recurrentes; filtros por estado de vigencia; integración con Conceptos (`esConceptoAsignable`). | La documentación original no incluye un archivo de pruebas; se asume que hay suite básica en `haberes-descuentos.service.spec.ts`. | No se cubre el cierre/desactivación en E2E; falta prueba de filtros por `ACTIVA`, `FUTURA`, `VENCIDA`, `CERRADA` e `INVALIDA`.  Pendiente integrar RLS y roles. |
| **Nómina mensual** | Reglas de prevalidación (`proceso-mensual-prevalidacion.rules.ts`, `proceso-mensual-parametros-minimos.rules.ts`, `proceso-mensual-recurrentes.rules.ts`), clasificador de estado global (`SIN_EVALUAR`, `LISTO_PARA_CALCULO`, etc.). | E2E para el flujo de `Validar periodo` en `/remuneraciones/proceso-mensual`, filtros por severidad (`BLOQUEO`, `ADVERTENCIA`, `INFO`), verificación de resumen y conteos. | Los archivos `prevalidaciones-9-5A.md` y `prevalidaciones-9-5B.md` no mencionan suites de test; se infiere que existen pruebas manuales o scripts. | Falta motor de cálculo y pruebas de liquidaciones; no hay cobertura de integración con Movimientos Variables o Haberes más allá de prevalidaciones. |

## Propuesta de ampliación

1. **Cobertura mínima de CRUD:** cuando los módulos expongan operaciones de creación, edición y cierre, se deben agregar pruebas E2E que recorran estos flujos de principio a fin.  Las pruebas deben validar mensajes, permisos y bloqueos según reglas de negocio.
2. **Pruebas de integración con roles/JWT/RLS:** la mayoría de los documentos mencionan RLS y permisos como pendientes.  Al implementar autenticación y autorización, deben añadirse pruebas para verificar que solo los perfiles autorizados puedan ejecutar acciones sensibles.
3. **Automatización de scripts Python:** aunque los scripts de carga no formen parte del frontend, conviene crear pruebas de integración (por ejemplo, con pytest) que validen los estados de `periodo_remuneracion` y la consistencia de tablas después de ejecutar `--modo preparar` y `--modo mensual`.
4. **Regresiones visuales:** renovar periódicamente las capturas bajo `docs/codex/assets/` y automatizar la comparación en CI para detectar cambios inesperados en UI.
5. **Brechas históricas:** los módulos carecen de E2E para ciertas pantallas (por ejemplo, ficha de empleado, edición de parámetros globales).  Se recomienda elaborar un backlog de pruebas manuales hasta que existan datos semilla y roles estabilizados.
6. **Pruebas de cumplimiento legal:** añadir casos de prueba que validen las reglas legales descritas en `normativa-remuneraciones.md`, como verificar que el sueldo base de cada trabajador no sea inferior al Ingreso Mínimo Mensual, que las horas extraordinarias se remuneren con un recargo mínimo del 50 %, que la reducción de jornada no genere disminución del sueldo, que la gratificación legal respete el tope de 4,75� IMM y que los conceptos clasificados como no remunerativos (locomoción, colación, indemnizaciones) se traten adecuadamente en los cálculos y reportes.

Este plan servirá como guía de referencia; deberá ajustarse cuando se publiquen nuevas fases del proyecto o se introduzcan cambios significativos en la aplicación.
## Fixtures minimos DOC-04

### Empleados

- periodo: `2026-04`
- sueldo_base: `539000`
- jornada: `42`
- edad: `30`
- afp: `Modelo`
- salud: `Fonasa`
- cargas: `1`

### Parametros

- IMM 18-65: `539000`
- Asignacion familiar tramo 1: `22007`
- Jornada maxima desde `2026-04-26`: `42`
- Ley 16.744 basica: `0.90`
- SIS: pendiente / segun fuente oficial mensual
