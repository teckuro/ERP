# Liquidaciones y comprobante de remuneraciones - referencia normativa minima

## Estado

Documento de apoyo para `LIQ-DESIGN-01`.

No reemplaza asesoria legal ni fija calculos. Resume criterios minimos que el ERP debe considerar al disenar liquidaciones oficiales.

## Regla base del comprobante

El comprobante/liquidacion debe permitir informar:

```txt
monto pagado
forma de determinacion
deducciones efectuadas
```

## Entrega digital

La entrega digital puede considerarse en fases futuras, usando medios como correo, intranet u otros, siempre separando:

```txt
generacion de liquidacion
entrega al trabajador
evidencia de recepcion
consentimiento para medio electronico si corresponde
```

En v1, `LIQ-OFICIAL-01` no debe implementar envio digital.

## Firma / recepcion

La firma del trabajador no debe modelarse como requisito legal obligatorio para generar la liquidacion oficial v1.

Puede existir en fase futura como evidencia de entrega/recepcion:

```txt
LIQ-FIRMA-01
LIQ-ENTREGA-01
```

## Reglas para el ERP

```txt
No bloquear generacion de liquidaciones por falta de firma.
No bloquear generacion por falta de correo si envio no es parte de la fase.
No activar PDF/firma/envio sin contrato propio.
No mezclar liquidacion oficial con Previred, LRE, banco o contabilidad.
```

## Fuentes oficiales de referencia

| Fuente | Tema |
|---|---|
| Direccion del Trabajo - Consulta "Comprobante de pago" | Entrega del comprobante por Internet/medios digitales bajo condiciones. |
| Direccion del Trabajo - ORD. N°2240/2017 | Obligacion de entregar comprobante con monto, determinacion y deducciones. |
| Direccion del Trabajo - ORD. N°4794/325 | Mismo criterio sobre comprobante y deducciones. |
| Direccion del Trabajo - ORD. N°4304/2014 | Firma en comprobantes/liquidaciones no debe tratarse como requisito obligatorio para v1. |
| Direccion del Trabajo - ORD. N°5207/2016 | Comunicacion electronica y consentimiento del destinatario. |
