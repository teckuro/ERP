# Fases

Indice canonico de fases documentales y funcionales.

## Liquidaciones

| Fase | Estado | Documento |
|---|---|---|
| `LIQ-DESIGN-01` | `en_diseno` | `liquidaciones/LIQ-DESIGN-01.md` |
| `LIQ-OFICIAL-01` | `pendiente` | futuro |
