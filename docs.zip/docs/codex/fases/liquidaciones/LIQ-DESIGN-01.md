# LIQ-DESIGN-01 - Diseno funcional y tecnico de liquidaciones oficiales

## Estado

| Campo | Valor |
|---|---|
| Modulo | Liquidaciones oficiales |
| Tipo | Documental / diseno funcional y tecnico |
| Estado | `en_diseno` |
| Dependencia fuerte | `NOM-CIERRE-DB-APPLY-01` validado en BD real/controlada |
| Siguiente fase | `LIQ-OFICIAL-01 - Implementar liquidaciones oficiales` |
| Fecha base | 2026-05-10 |

Esta fase define el contrato para implementar liquidaciones oficiales. No implementa SQL, RPC, RLS, Angular, PDF, firma, envio, Previred, LRE, banco ni contabilidad.

## Objetivo

Disenar el flujo de **Liquidaciones oficiales** como etapa posterior al cierre operativo de nomina.

Flujo objetivo:

```txt
Preparar nomina
-> Resultado preliminar guardado
-> Aprobacion operativa
-> Cierre operativo validado
-> Liquidaciones oficiales
```

## Alcance

Esta fase documenta:

- Definicion funcional de liquidacion oficial v1.
- Precondiciones para generar liquidaciones.
- Contrato de datos sugerido.
- Contrato UI/UX.
- Estados visibles.
- Bloqueos y advertencias.
- Contrato tecnico futuro para `LIQ-OFICIAL-01`.
- Validaciones esperadas.
- Relacion con PDF, firma, Previred, LRE, banco y contabilidad.

## Fuera de alcance

No implementar ni marcar como implementado:

- SQL.
- RPC.
- RLS.
- Angular.
- Rutas.
- Componentes.
- Tests.
- PDF oficial.
- Firma o recepcion.
- Envio por correo.
- Portal trabajador.
- Previred.
- LRE operativo.
- Archivo banco.
- Contabilidad.
- Reapertura.
- Anulacion.
- Rectificacion.
- Reliquidacion.

## Estado actual

El ERP ya tiene documentado el cierre operativo como validado en BD real/controlada:

```txt
NOM-CIERRE-DB-APPLY-01
-> columnas cierre_operativo_* validadas
-> RPC cerrar_nomina_operativa validada
-> permisos authenticated=true / anon=false
-> cierre real E2E validado para periodo controlado
```

Liquidaciones oficiales aun no existen como implementacion funcional.

## Base normativa minima

La liquidacion/comprobante debe permitir informar:

```txt
monto pagado
forma de determinacion
deducciones efectuadas
```

La entrega digital del comprobante puede ser valida bajo condiciones, pero el flujo de envio/recepcion no pertenece a v1.

La firma del trabajador no debe modelarse como requisito legal obligatorio en v1. Puede tratarse como evidencia futura de entrega/recepcion si el producto lo requiere.

### Fuentes oficiales de referencia

| Fuente | Uso documental |
|---|---|
| Direccion del Trabajo, consulta sobre comprobante de pago | Entrega digital del comprobante por medios como correo o intranet bajo condiciones. |
| Direccion del Trabajo, ORD. N°2240/2017 y ORD. N°4794/325 | Comprobante con monto pagado, forma de determinacion y deducciones. |
| Direccion del Trabajo, ORD. N°4304/2014 / criterio asociado | La firma en liquidaciones no debe tratarse como requisito legal obligatorio para v1. |
| Direccion del Trabajo, ORD. N°5207/2016 | Comunicacion electronica requiere consentimiento; si no existe, corresponde soporte papel. |

Regla:

```txt
No copiar textos legales extensos.
No inventar obligaciones.
Separar requisito legal, decision de producto y fase futura.
```

## Definicion funcional v1

La liquidacion oficial es el comprobante consolidado por trabajador, generado desde un snapshot de nomina cerrado operativamente, que presenta haberes, descuentos, bases, referencias y liquido a pagar del periodo, con trazabilidad al calculo que la origino.

Principio central:

```txt
La liquidacion oficial no recalcula.
La liquidacion oficial materializa y presenta el snapshot cerrado.
```

## Decisiones propuestas para cerrar

| Codigo | Decision | Estado recomendado |
|---|---|---|
| LIQ-DEC-001 | Fuente de verdad | Snapshot cerrado, no recalculo |
| LIQ-DEC-002 | Precondicion | Exigir cierre operativo |
| LIQ-DEC-003 | Persistencia | Tablas nuevas |
| LIQ-DEC-004 | Granularidad | Cabecera periodo + trabajador + detalle concepto |
| LIQ-DEC-005 | Estado v1 | Solo `generada` |
| LIQ-DEC-006 | Regeneracion | Bloquear si ya existen liquidaciones para el cierre |
| LIQ-DEC-007 | PDF | Fuera de v1 |
| LIQ-DEC-008 | Firma/recepcion | Fuera de v1 |
| LIQ-DEC-009 | LRE/Previred/banco/contabilidad | Futuros, no v1 |

## Precondiciones para generar liquidaciones

```txt
[ ] periodo seleccionado valido
[ ] existe snapshot activo
[ ] snapshot esta aprobado operativamente
[ ] snapshot esta cerrado operativamente
[ ] snapshot no esta reemplazado
[ ] no existen liquidaciones oficiales generadas para ese snapshot
[ ] existen trabajadores calculados en el snapshot
[ ] usuario tiene sesion authenticated
```

## Bloqueos

Bloquear generacion si:

```txt
no hay snapshot guardado
snapshot no aprobado
snapshot no cerrado
snapshot reemplazado
nomina con cierre inconsistente
ya existen liquidaciones generadas
no hay trabajadores calculados
error de permisos/auth
```

## Advertencias no bloqueantes

No bloquear por requisitos de fases futuras.

Ejemplos:

```txt
conceptos sin codigo LRE
correo trabajador faltante
datos bancarios incompletos
firma/recepcion no configurada
observaciones informativas del trabajador
```

## Contrato de datos propuesto

### Tabla cabecera

```txt
nomina_liquidacion_periodo
```

Campos sugeridos:

```txt
id_liquidacion_periodo
id_empresa
periodo
id_calculo_periodo
estado
fecha_generacion
usuario_generacion_id
usuario_generacion_label
total_trabajadores
total_haberes
total_descuentos
total_liquido
metadata
created_at
updated_at
```

Reglas:

```txt
id_calculo_periodo debe referenciar snapshot cerrado
estado v1 = generada
no debe existir mas de una liquidacion generada activa por id_calculo_periodo en v1
```

### Tabla trabajador

```txt
nomina_liquidacion_trabajador
```

Campos sugeridos:

```txt
id_liquidacion_trabajador
id_liquidacion_periodo
id_calculo_periodo
id_persona
id_contrato
rut
nombre_trabajador
cargo
centro_costo
fecha_ingreso
dias_trabajados
base_imponible
base_tributable
total_haberes
total_descuentos
total_aportes_empleador_referencia
liquido_pagar
estado
metadata
created_at
updated_at
```

### Tabla detalle conceptos

```txt
nomina_liquidacion_concepto
```

Campos sugeridos:

```txt
id_liquidacion_concepto
id_liquidacion_trabajador
id_concepto
codigo
codigo_lre
nombre
tipo
clasificacion
cantidad
base
tasa
monto
orden
metadata
created_at
```

Tipos sugeridos, ajustables al modelo real:

```txt
haber_imponible
haber_no_imponible
descuento_legal
descuento_voluntario
impuesto
aporte_empleador_referencia
informativo
```

## Metadata minima

Cabecera:

```json
{
  "origen": "snapshot_cerrado",
  "notaAlcance": "Liquidacion oficial generada desde cierre operativo. No genera PDF, Previred, LRE, banco ni contabilidad.",
  "versionContrato": "LIQ-OFICIAL-v1"
}
```

Trabajador:

```json
{
  "fuente": "nomina_calculo_trabajador",
  "observaciones": []
}
```

Concepto:

```json
{
  "fuente": "nomina_calculo_concepto",
  "trazabilidad": []
}
```

## Contrato tecnico futuro para LIQ-OFICIAL-01

### Feature Angular recomendada

```txt
src/app/features/liquidaciones-oficiales/
```

Estructura sugerida:

```txt
models/
data-access/
services/
containers/
components/
rules/
```

Ejemplo:

```txt
src/app/features/liquidaciones-oficiales/models/liquidacion-oficial.model.ts
src/app/features/liquidaciones-oficiales/data-access/liquidaciones-oficiales.repository.ts
src/app/features/liquidaciones-oficiales/services/liquidaciones-oficiales.service.ts
src/app/features/liquidaciones-oficiales/containers/liquidaciones-oficiales-container/
src/app/features/liquidaciones-oficiales/components/liquidacion-resumen-card/
src/app/features/liquidaciones-oficiales/components/liquidaciones-trabajadores-grid/
src/app/features/liquidaciones-oficiales/components/liquidacion-detalle-panel/
```

Regla estructural:

```txt
No crear pantalla operativa compleja directamente en pages.
Usar feature con containers, components, services/data-access, models y specs.
Pages solo wrapper simple si aplica.
```

### Ruta futura sugerida

```txt
/remuneraciones/liquidaciones-oficiales
```

### RPC futura recomendada

```txt
generar_liquidaciones_oficiales
```

Debe ser atomica:

```txt
validar snapshot cerrado
validar no existen liquidaciones previas para id_calculo_periodo
insertar cabecera
insertar trabajadores
insertar conceptos
confirmar totales
retornar cabecera generada
```

Permisos:

```txt
authenticated puede ejecutar
anon no puede ejecutar
security invoker
```

No usar `service_role` desde frontend.

## Contrato UI/UX

### Pantalla propuesta

```txt
Header operativo
Estado del periodo
Resumen de liquidaciones
Siguiente accion
Bloqueos/advertencias
Listado de trabajadores
Detalle lateral o vista detalle
Trazabilidad tecnica secundaria
```

### Estados visibles

```txt
No disponible
Lista para generar
Generando
Generadas
Generadas con advertencias
Error de generacion
```

### Boton principal v1

```txt
Generar liquidaciones oficiales
```

Helper obligatorio:

```txt
Se generaran comprobantes por trabajador desde la nomina cerrada. No se recalcularan montos ni se generaran PDF, Previred, LRE, banco o contabilidad.
```

### Empty states

Sin cierre:

```txt
Aun no puedes generar liquidaciones oficiales.
Primero debes cerrar operativamente la nomina del periodo.
```

Sin trabajadores:

```txt
No hay trabajadores calculados para generar liquidaciones.
Revisa el resultado cerrado de nomina.
```

Ya generadas:

```txt
Las liquidaciones oficiales del periodo ya fueron generadas.
Puedes revisar el detalle por trabajador.
```

### Detalle trabajador

Debe mostrar:

```txt
datos trabajador
periodo
haberes imponibles
haberes no imponibles
descuentos legales
otros descuentos
impuesto si aplica
liquido a pagar
observaciones
trazabilidad
```

IDs tecnicos solo en detalle secundario.

## Diseno usable/comercial

Principios:

```txt
claro antes que tecnico
estado visible arriba
siguiente accion evidente
monto liquido destacado
detalle ordenado por grupos
trazabilidad disponible pero secundaria
sin saturar con IDs ni tablas crudas
```

Evitar:

```txt
mostrar JSON crudo
mezclar LRE/Previred/banco en la pantalla principal
botones futuros activos
texto legal largo en UI
```

## Validaciones futuras para LIQ-OFICIAL-01

### Unitarias

```txt
no genera sin cierre operativo
no genera si snapshot no aprobado
no genera si ya existen liquidaciones
genera cabecera con totales correctos desde snapshot
genera liquidacion por trabajador
genera detalle por concepto
no recalcula montos
mapea observaciones
muestra estados UI correctos
```

### E2E

```txt
login
-> periodo cerrado
-> abrir liquidaciones oficiales
-> generar liquidaciones
-> recargar
-> liquidaciones persisten
-> abrir detalle trabajador
-> validar liquido/haberes/descuentos visibles
-> confirmar que PDF/Previred/LRE/banco no estan activos
```

### SQL post-generacion

```txt
cabecera generada
cantidad de trabajadores coincide con snapshot cerrado
cantidad de conceptos coincide con conceptos por trabajador
totales cabecera = suma trabajadores
no hay duplicados para id_calculo_periodo
snapshot origen cerrado
```

## Relacion con fases siguientes

| Fase | Relacion |
|---|---|
| `LIQ-OFICIAL-01` | Implementa tablas/RPC/feature/UI minima de liquidaciones oficiales |
| `UX-COMERCIAL-01` | Mejora experiencia usable y comercial despues de liquidaciones |
| `LIQ-PDF-01` | Futuro: PDF oficial |
| `LIQ-FIRMA-01` | Futuro: firma/recepcion |
| `PREVIRED-DESIGN-01` | Futuro posterior, no inmediato |
| `LRE-DESIGN-01` | Futuro posterior, no inmediato |
| `BANCO-DESIGN-01` | Futuro posterior, no inmediato |
| `CONTABILIDAD-DESIGN-01` | Futuro posterior, no inmediato |

## Criterios de cierre de LIQ-DESIGN-01

```txt
[ ] Liquidaciones oficiales queda definido como modulo/flujo futuro inmediato.
[ ] Queda claro que no recalcula.
[ ] Queda claro que requiere cierre operativo.
[ ] Queda claro que no genera PDF en v1.
[ ] Queda claro que no implementa firma/recepcion.
[ ] Queda claro que no genera Previred/LRE/banco/contabilidad.
[ ] Queda propuesto contrato de tablas.
[ ] Queda propuesto contrato de RPC futura.
[ ] Queda propuesto contrato UI/UX.
[ ] Quedan definidos estados visibles.
[ ] Quedan definidos bloqueos y advertencias.
[ ] Quedan definidos criterios de aceptacion para LIQ-OFICIAL-01.
[ ] Roadmap deja siguiente fase como LIQ-OFICIAL-01.
```

## Nota final

No implementar liquidaciones en esta fase.

La frontera correcta es:

```txt
Cierre operativo validado
-> Liquidaciones oficiales disenadas
-> Liquidaciones oficiales implementables
```
# Implementacion LIQ-OFICIAL-01 - 2026-05-10

El diseno fue implementado como liquidaciones oficiales internas v1:

- materializacion desde `nomina_calculo_periodo` cerrado operativamente;
- tablas `nomina_liquidacion_periodo`, `nomina_liquidacion_trabajador`, `nomina_liquidacion_concepto`;
- RPC `generar_liquidaciones_oficiales`;
- UI `/remuneraciones/liquidaciones-oficiales` con resumen, grilla y detalle por trabajador;
- sin recalculo y sin PDF/firma/envio/Previred/LRE/banco/contabilidad.
